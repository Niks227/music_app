<?php
	$con->close ();
?>