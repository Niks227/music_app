<?php
	/**
	* 
	*/
	class send_timeline
	{
		
		function __construct()
		{
		}
		public static function show($muic_info)
		{
			echo "<br>Music send!!<br>";
		}
	}
?>