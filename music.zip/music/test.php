<?php
include 'errorHandling.php';
$error = new errorHandling("464","TestingError");
$error->send();


?>